const secretKey = "itss-back-end";

module.exports = {
  secretKey,
};
