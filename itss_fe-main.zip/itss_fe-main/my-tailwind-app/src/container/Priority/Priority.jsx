import React, {useState} from "react";
import 'react-responsive-modal/styles.css';
const Priority = () => {
  return (
    <div>Priority</div>
  );
};

export default Priority;
